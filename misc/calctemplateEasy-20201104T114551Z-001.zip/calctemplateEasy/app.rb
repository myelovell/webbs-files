# 1. Kontrolleraa att slim, sinatra och sessions kan avändas i denna fil. Mappstruktur ok? Slimfiler ok?

output=[]

get('/') do
  slim(:calculator)
end

post('/calculate') do
  
  # 2. Hämta upp värdena ifrån formuläret, gör dem till datatyp float.

  # 3. Beroende på operator (+,-,*,-) lägg rätt resultat i output. 
  # Använd 'If/elseif/' eller testa 'case': https://www.rubyguides.com/2015/10/ruby-case/ 
 
  # 4. Lägg output i en session
  

  # 5 redirecta till GET
  
end

# 6. Visa upp historiken (output) i calculator.slim. Lös mha session (ej locals). 

# 7. Lägg till funktionalitet för att tömma historiken.

# 8. Felhantering (1: Slimresultat om session är tom?, 2: Värdet "0" används i division).
