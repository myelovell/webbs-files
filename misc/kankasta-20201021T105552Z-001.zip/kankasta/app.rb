require 'sinatra'
require 'slim'

#gem install sinatra
#ruby app.rb (starta igång)
#CTRL + C (stäng av server)
#localhost:4567 (kör sida i Chrome)

 get('/indexbanan1') do
   slim(:index)
 end

 get('/car') do
  theCar = "Audi"
  slim(:car, locals:{car:theCar})

 end

 get('/names') do
  names = ["Emil","Molly","Ester"]
  slim(:names,locals:{key:names})
 end

 get('/boxar') do
    value = ["blue","hotpink","red"]
   slim(:boxar,locals:{colors:value})
 end




#1
get('/') do
  return "HelloWorld"
end



#2
get('/about') do
  return "<h1>Min lilla rubrik</h1>"
end

#3
get('/links') do
  return '<a href="/about">ABOUTSIDAN</a>'
end



get('/emilshemligaundersida') do
  return "Hur hittade du hit?!"
end

get('/fruits/:fruit_id') do
	list = ["Apple", "Orange", "Banana", "Grillkorv"]
	fruit_id = params["fruit_id"].to_i

	response = list[ fruit_id ]

	return response
end






# post('/data') do
#   ...
#   redirect('/')
# end




